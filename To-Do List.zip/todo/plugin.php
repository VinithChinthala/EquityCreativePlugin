<?php
/*
Plugin Name: To-Do List
Plugin URI: 
Description: Simple To-Do List for Equity Creative Programming Task
Version: 1.0
Author: Vinith Chinthala

*/

add_action("admin_menu","addMenu1");
function addMenu1()
{
add_menu_page('Equity Creative Plugin','To-Do List',4,'Sample_Page','footer_text_admin_page');
}
function footer_text_admin_page(){
echo "<h2>" .__('','menu-test'). "</h2>";
include "includes/index.php";
}
?>