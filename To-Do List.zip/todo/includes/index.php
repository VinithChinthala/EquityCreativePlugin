<html>
<head>
<style>


table {
	background: #ffffff;
	border-collapse: separate;
	box-shadow: inset 0 1px 0 #fff;
	font-size: 12px;
	line-height: 24px;
	margin: 30px auto;
	text-align: left;
	width: 800px;
}


th {
	background: linear-gradient(#777, #444);
	border-left: 1px solid #555;
	border-right: 1px solid #777;
	border-top: 1px solid #555;
	border-bottom: 1px solid #333;
	box-shadow: inset 0 1px 0 #999;
	color: #fff;
  font-weight: bold;
	padding: 10px 15px;
	position: relative;
	text-shadow: 0 1px 0 #000;	
}


td {
	border-right: 1px solid #fff;
	border-left: 1px solid #e8e8e8;
	border-top: 1px solid #fff;
	border-bottom: 1px solid #e8e8e8;
	padding: 10px 15px;
	position: relative;
	transition: all 300ms;
}

td:first-child {
	box-shadow: inset 1px 0 0 #fff;
}	

td:last-child {
	border-right: 1px solid #e8e8e8;
	box-shadow: inset -1px 0 0 #fff;
}	

tr {
	background: url(http://jackrugile.com/images/misc/noise-diagonal.png);	
}

tr:nth-child(odd) td {
	background: #f1f1f1 url(http://jackrugile.com/images/misc/noise-diagonal.png);	
}

tr:last-of-type td {
	box-shadow: inset 0 -1px 0 #fff; 
}

tr:last-of-type td:first-child {
	box-shadow: inset 1px -1px 0 #fff;
}	

tr:last-of-type td:last-child {
	box-shadow: inset -1px -1px 0 #fff;
}	

tbody:hover td {
	color: transparent;
	text-shadow: 0 0 3px #aaa;
}

tbody:hover tr:hover td {
	color: #444;
	text-shadow: 0 1px 0 #fff;
}

body {
	color: #1a1a1a;
	font-family: Merriweather, Georgia, serif;
	font-size: 16px;
	font-weight: 400;
	line-height: 1.75;
	margin: 20px 40px;
	max-width: 600px;
	vertical-align: baseline;
}

body.post-type-page {
	max-width: 840px;
}


/**
 * 2.0 - Typography
 */

h1,
h2,
h3,
h4,
h5,
h6 {
	clear: both;
	font-weight: 900;
	margin: 56px 0 28px;
}

h1 {
	font-size: 33px;
	line-height: 1.2727272727;
}

h2 {
	font-size: 28px;
	line-height: 1.25;
}

h3 {
	font-size: 23px;
	line-height: 1.2173913043;
}

h4,
h5,
h6 {
	font-size: 19px;
	line-height: 1.1052631579;
}

h4 {
	letter-spacing: 0.13333em;
	text-transform: uppercase;
}

h6 {
	font-style: italic;
}

h1:first-child,
h2:first-child,
h3:first-child,
h4:first-child,
h5:first-child,
h6:first-child {
	margin-top: 0;
}

p {
	margin: 0 0 28px;
}

b,
strong {
	font-weight: 700;
}

dfn,
cite,
em,
i {
	font-style: italic;
}

blockquote {
	border-left: 4px solid #1a1a1a;
	color: #686868;
	font-size: 19px;
	font-style: italic;
	line-height: 1.4736842105;
	margin-bottom: 28px;
	overflow: hidden;
	padding: 0 0 0 24px;
}

blockquote:not(.alignleft):not(.alignright) {
	margin-left: -28px;
}

blockquote blockquote:not(.alignleft):not(.alignright) {
	margin-left: 0;
}

blockquote:before,
blockquote:after {
	content: "";
	display: table;
}

blockquote:after {
	clear: both;
}

blockquote > :last-child {
	margin-bottom: 0;
}

blockquote cite,
blockquote small {
	color: #1a1a1a;
	font-size: 16px;
	line-height: 1.75;
}

blockquote em,
blockquote i,
blockquote cite {
	font-style: normal;
}

blockquote strong,
blockquote b {
	font-weight: 400;
}

blockquote.alignleft,
blockquote.alignright {
	border: 0 solid #1a1a1a;
	border-top-width: 4px;
	padding: 18px 0 0;
	width: -webkit-calc(50% - 14px);
	width: calc(50% - 14px);
}

address {
	font-style: italic;
	margin: 0 0 28px;
}

code,
kbd,
tt,
var,
samp,
pre {
	font-family: Inconsolata, monospace;
}

pre {
	border: 1px solid #d1d1d1;
	font-size: 16px;
	line-height: 1.3125;
	margin: 0 0 28px;
	max-width: 100%;
	overflow: auto;
	padding: 14px;
	white-space: pre;
	white-space: pre-wrap;
	word-wrap: break-word;
}

code {
	background-color: #d1d1d1;
	padding: 2px 4px;
}

abbr[title] {
	border-bottom: 1px dotted #d1d1d1;
	cursor: help;
}

mark,
ins {
	background: #007acc;
	color: #fff;
	padding: 2px 4px;
	text-decoration: none;
}

sup,
sub {
	font-size: 75%;
	height: 0;
	line-height: 0;
	position: relative;
	vertical-align: baseline;
}

sub {
	top: -6px;
}

sup {
	bottom: -3px;
}

small {
	font-size: 80%;
}

big {
	font-size: 125%;
}
















</style>
<script>
</script>
</head>
<body>

<form action="" method="POST">

<div style="overflow: hidden; padding-right:.5em;">
<center>
<div>

<center>
<div>

<h4>Please Add your To-Do Tasks</h4>
 <input type="text" name="textbox"/>
<input type="Submit" name="insert" value="add"/>
</div>
</center>



<center>
</br>

<table >
<tr>
<th>
<h4>To Do List</h4>
</th>

</tr>
<?php
global $wpdb;
if(isset($_POST ['edit']))
{
$ID=$_POST ['edit'];
$wpdb->update('todolist',array('Status'=>1),array('Item_ID'=> $ID), array( '%d', '%d' ), array( '%d' ));
}
if(isset($_POST ['unitemedit']))
{
$ID=$_POST ['unitemedit'];
$wpdb->update('todolist',array('Status'=>0),array('Item_ID'=>$ID), array( '%d', '%d' ), array( '%d' ));
}
if(isset($_POST ['insert']))
{
$wpdb->insert('todolist',array('Item_Description'=> $_POST ['textbox'],'STATUS'=>'0'));
}
$mytasks=$wpdb->get_results("SELECT * FROM TODOLIST ORDER by STATUS");
foreach($mytasks as $mytask)
{
if($mytask->Status==1)
{
echo '<tr><td><button name="unitemedit" value='.$mytask->Item_ID.'>Un-check for not Completed</button>';
echo'<input type="hidden" name="unitemid" value='.$mytask->Item_ID.'>';
echo '&nbsp&nbsp&nbsp<strike><input type="checkbox" name="comptask" value="1" checked="checked">'.$mytask->Item_Description.'</strike></td></tr>';

}
else{
echo '<tr><td><button name="edit" value='.$mytask->Item_ID.'>Check the box if Completed</button>';
echo'<input type="hidden" name="itemid" value='.$mytask->Item_ID.'>';
echo '&nbsp&nbsp&nbsp<input type="checkbox"value="0" name="nocomptask"><b>'.$mytask->Item_Description.'</b></td>';
echo'<input type="hidden" name="check"></tr>';



}

}
?>

</table>
</center>
</div>
</form>
</body>
</html>